from neuralcore.data import generate_dataset, FEATURES


def test_dataset_is_reproducible():
    first = generate_dataset(200, 7)
    second = generate_dataset(200, 7)
    assert first.equals(second)


def test_dataset_schema_and_size():
    data = generate_dataset(150, 42)
    assert len(data) == 150
    assert set(FEATURES).issubset(data.columns)
    assert set(data["churn"].unique()).issubset({0, 1})
