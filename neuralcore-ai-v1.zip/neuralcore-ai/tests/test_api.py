import pytest
from fastapi.testclient import TestClient
from neuralcore.api import app
from neuralcore.train import train_and_save


@pytest.fixture(scope="module", autouse=True)
def trained_model():
    train_and_save()


def test_health_endpoint():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["model_ready"] is True


def test_prediction_endpoint():
    client = TestClient(app)
    response = client.post("/predict", json={
        "tenure_months": 18,
        "monthly_charges": 79.5,
        "support_tickets": 3,
        "contract_type": "month_to_month",
        "payment_method": "electronic",
    })
    assert response.status_code == 200
    body = response.json()
    assert 0 <= body["churn_probability"] <= 1
    assert body["risk_level"] in {"low", "medium", "high"}


def test_invalid_prediction_is_rejected():
    client = TestClient(app)
    response = client.post("/predict", json={
        "tenure_months": -5,
        "monthly_charges": 79.5,
        "support_tickets": 3,
        "contract_type": "month_to_month",
        "payment_method": "electronic",
    })
    assert response.status_code == 422
