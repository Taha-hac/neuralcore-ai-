from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = PROJECT_ROOT / "artifacts"
MODEL_PATH = ARTIFACT_DIR / "churn_model.joblib"
RANDOM_STATE = 42
MODEL_VERSION = "1.0.0"
