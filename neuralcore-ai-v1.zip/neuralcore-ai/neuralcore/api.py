from fastapi import FastAPI, HTTPException
import joblib
import pandas as pd

from neuralcore.config import MODEL_PATH, MODEL_VERSION
from neuralcore.schemas import CustomerFeatures, PredictionResponse

app = FastAPI(
    title="NeuralCore AI API",
    description="Explainable-demo API for synthetic customer churn analysis.",
    version=MODEL_VERSION,
)


def load_artifact():
    if not MODEL_PATH.exists():
        raise RuntimeError("Model artifact not found. Run `python -m neuralcore.train` first.")
    return joblib.load(MODEL_PATH)


@app.get("/health", tags=["system"])
def health():
    return {"status": "ok", "model_ready": MODEL_PATH.exists(), "version": MODEL_VERSION}


@app.get("/metrics", tags=["model"])
def metrics():
    try:
        return load_artifact()["metrics"]
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/predict", response_model=PredictionResponse, tags=["inference"])
def predict(payload: CustomerFeatures):
    try:
        artifact = load_artifact()
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    row = pd.DataFrame([payload.model_dump()])
    probability = float(artifact["model"].predict_proba(row)[0, 1])
    level = "high" if probability >= 0.7 else "medium" if probability >= 0.4 else "low"
    return PredictionResponse(
        churn_probability=round(probability, 4),
        risk_level=level,
        model_version=MODEL_VERSION,
    )
