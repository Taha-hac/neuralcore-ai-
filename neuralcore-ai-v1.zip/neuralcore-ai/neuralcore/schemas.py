from typing import Literal
from pydantic import BaseModel, Field, ConfigDict


class CustomerFeatures(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tenure_months: int = Field(ge=0, le=120, examples=[18])
    monthly_charges: float = Field(ge=0, le=1000, examples=[79.5])
    support_tickets: int = Field(ge=0, le=100, examples=[3])
    contract_type: Literal["month_to_month", "one_year", "two_year"]
    payment_method: Literal["electronic", "bank_transfer", "card"]


class PredictionResponse(BaseModel):
    churn_probability: float
    risk_level: Literal["low", "medium", "high"]
    model_version: str
