from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.datasets import make_classification

NUMERIC_FEATURES = ["tenure_months", "monthly_charges", "support_tickets"]
CATEGORICAL_FEATURES = ["contract_type", "payment_method"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def generate_dataset(n_samples: int = 2500, random_state: int = 42) -> pd.DataFrame:
    """Generate deterministic synthetic churn-like data for demonstration."""
    if n_samples < 100:
        raise ValueError("n_samples must be at least 100")

    x, y = make_classification(
        n_samples=n_samples,
        n_features=3,
        n_informative=3,
        n_redundant=0,
        n_classes=2,
        weights=[0.72, 0.28],
        class_sep=0.9,
        flip_y=0.04,
        random_state=random_state,
    )
    rng = np.random.default_rng(random_state)
    tenure = np.clip((x[:, 0] * 8 + 24).round(), 1, 72).astype(int)
    charges = np.clip(x[:, 1] * 18 + 75, 20, 160).round(2)
    tickets = np.clip((x[:, 2] * 2.2 + 3).round(), 0, 12).astype(int)

    # Categorical values are generated independently to keep the example simple.
    contracts = rng.choice(
        ["month_to_month", "one_year", "two_year"],
        size=n_samples,
        p=[0.58, 0.27, 0.15],
    )
    payments = rng.choice(
        ["electronic", "bank_transfer", "card"],
        size=n_samples,
        p=[0.48, 0.27, 0.25],
    )

    return pd.DataFrame({
        "tenure_months": tenure,
        "monthly_charges": charges,
        "support_tickets": tickets,
        "contract_type": contracts,
        "payment_method": payments,
        "churn": y.astype(int),
    })
