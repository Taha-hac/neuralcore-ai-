# NeuralCore AI
### An explainable machine-learning platform for customer churn analysis

**Author:** Taha Bahrevar  
**Repository:** `Taha-hac/neuralcore-ai`  
**Status:** Portfolio project — v1.0.0

NeuralCore AI is a reproducible, end-to-end machine-learning application that trains a customer-churn classifier on a clearly labelled **synthetic dataset**, serves predictions through a FastAPI REST API, and provides an interactive Streamlit dashboard.

> **Important:** The included data is synthetic and generated for software demonstration. Model metrics are not evidence of real-world business performance. Do not use this model to make decisions about real customers.

## Features

- Reproducible synthetic dataset generation
- Scikit-learn preprocessing and Random Forest classifier
- Train/test split with stratification and fixed random seed
- Evaluation: precision, recall, F1, ROC-AUC, confusion matrix
- FastAPI endpoints for health, model metrics, and predictions
- Streamlit dashboard for interactive predictions
- Input validation with Pydantic
- Unit tests with pytest
- Dockerfile and GitHub Actions CI workflow
- Model artifact generated locally (not committed)

## Architecture

```text
Synthetic data generator
        |
        v
Training pipeline (scikit-learn)
        | saves
        v
artifacts/churn_model.joblib
        |
        +-------------------+
        |                   |
        v                   v
 FastAPI REST API      Streamlit UI
        |
        v
 /health  /metrics  /predict
```

## Quick start

Requires Python 3.10–3.12.

```bash
# 1. Create and activate a virtual environment
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Train the model and create the artifact
python -m neuralcore.train

# 4. Start the API (terminal 1)
uvicorn neuralcore.api:app --reload

# 5. Start the dashboard (terminal 2)
streamlit run dashboard/app.py
```

Open:
- API docs: http://127.0.0.1:8000/docs
- Dashboard: http://localhost:8501
- Health: http://127.0.0.1:8000/health

## API example

```bash
curl -X POST "http://127.0.0.1:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "tenure_months": 18,
    "monthly_charges": 79.5,
    "support_tickets": 3,
    "contract_type": "month_to_month",
    "payment_method": "electronic"
  }'
```

Example response:

```json
{
  "churn_probability": 0.73,
  "risk_level": "high",
  "model_version": "1.0.0"
}
```

The probability above is illustrative; actual output depends on the trained model artifact.

## Project structure

```text
neuralcore-ai/
├── dashboard/
│   └── app.py
├── neuralcore/
│   ├── __init__.py
│   ├── api.py
│   ├── config.py
│   ├── data.py
│   ├── schemas.py
│   └── train.py
├── tests/
│   ├── test_data.py
│   └── test_api.py
├── .github/workflows/ci.yml
├── artifacts/.gitkeep
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── LICENSE
├── Makefile
└── requirements.txt
```

## Reproducibility

The generator uses a fixed seed (`42`). Running the training command creates the model artifact locally in `artifacts/`. The artifact is intentionally excluded from Git so that the repository stays lightweight and the model can be rebuilt from source.

## Responsible use and limitations

- Training examples are synthetic, not customer records.
- This is an educational portfolio project, not a production churn system.
- Synthetic-data metrics can look better or worse than real-world performance.
- Do not infer causality from feature importance.
- Before any real deployment, validate on representative, consented data; assess subgroup performance, calibration, drift, privacy, and business impact.

## Roadmap

- [ ] Add model calibration and threshold selection
- [ ] Add explainability with SHAP
- [ ] Add experiment tracking
- [ ] Add database-backed prediction history
- [ ] Add authentication and rate limiting
- [ ] Deploy a public demo with secrets managed securely

## Author

**Taha Bahrevar** — aspiring software and AI developer.

This project is intended to demonstrate practical learning in Python, machine learning, API design, testing, and technical documentation.
