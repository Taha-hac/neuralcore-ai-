import requests
import streamlit as st

API_URL = st.sidebar.text_input("API URL", "http://127.0.0.1:8000")

st.set_page_config(page_title="NeuralCore AI", page_icon="🧠", layout="wide")
st.title("🧠 NeuralCore AI")
st.caption("Customer churn analysis · Machine-learning portfolio project")
st.info("Educational demo using synthetic data only. Not for real customer decisions.")

with st.sidebar:
    st.header("Customer profile")
    tenure = st.slider("Tenure (months)", 0, 72, 18)
    charges = st.number_input("Monthly charges", min_value=0.0, max_value=1000.0, value=79.5)
    tickets = st.slider("Support tickets", 0, 20, 3)
    contract = st.selectbox("Contract", ["month_to_month", "one_year", "two_year"])
    payment = st.selectbox("Payment method", ["electronic", "bank_transfer", "card"])
    run = st.button("Analyze profile", type="primary", use_container_width=True)

col1, col2 = st.columns([1.2, 1])
with col1:
    st.subheader("Prediction")
    if run:
        payload = {
            "tenure_months": tenure,
            "monthly_charges": charges,
            "support_tickets": tickets,
            "contract_type": contract,
            "payment_method": payment,
        }
        try:
            response = requests.post(f"{API_URL}/predict", json=payload, timeout=10)
            response.raise_for_status()
            result = response.json()
            st.metric("Estimated churn probability", f"{result['churn_probability']:.1%}")
            st.metric("Risk category", result["risk_level"].upper())
            st.caption(f"Model version: {result['model_version']}")
        except requests.RequestException as exc:
            st.error(f"Could not reach the API: {exc}")
    else:
        st.write("Choose a profile in the sidebar and select **Analyze profile**.")

with col2:
    st.subheader("Model evaluation")
    try:
        metrics = requests.get(f"{API_URL}/metrics", timeout=5).json()
        st.metric("Accuracy", f"{metrics['accuracy']:.1%}")
        st.metric("Precision", f"{metrics['precision']:.1%}")
        st.metric("Recall", f"{metrics['recall']:.1%}")
        st.metric("ROC-AUC", f"{metrics['roc_auc']:.3f}")
        st.caption(f"Evaluation samples: {metrics['test_samples']} · Synthetic dataset")
    except requests.RequestException:
        st.warning("Start the API to display evaluation metrics.")
