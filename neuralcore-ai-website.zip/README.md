# NeuralCore AI

**An experimental, human-centered AI interface concept by Taha Bahrevar.**

NeuralCore AI explores how a clear and accessible interface can shape interactions with artificial intelligence. This repository contains a responsive front-end landing page and a small local interaction demo.

## Live preview

After enabling GitHub Pages, the site will be available at:

https://taha-hac.github.io/neuralcore-ai-/

## Current features

- Responsive dark interface
- Project vision and design principles
- Interactive front-end chat preview
- Mobile-friendly layout
- No external dependencies or build step

## Important project status

This is a **front-end prototype**. The chat preview uses illustrative local responses; it is **not connected to an AI model or backend API**. A real model integration, backend, authentication, and persistent conversations are not implemented.

## Run locally

Open `index.html` in a modern web browser.

## Deployment with GitHub Pages

1. Open the repository's **Settings**.
2. Select **Pages** from the sidebar.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then save.
5. Wait for the Pages deployment workflow to finish.

## Author

**Taha Bahrevar**  
GitHub: [@Taha-hac](https://github.com/Taha-hac)

*Built as an independent learning and portfolio project.*
